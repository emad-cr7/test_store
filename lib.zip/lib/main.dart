import 'package:flutter/material.dart';
import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:provider/provider.dart';
import 'core/Preferences_manager/preferences_manager.dart';
import 'core/api/api_config/api_config.dart';
import 'features/home/home_controller.dart';
import 'main/main_screen.dart';

void main() async{

  WidgetsFlutterBinding.ensureInitialized();


  final HttpLink httpLink = HttpLink(ApiConfig.baseUrl);

  final ValueNotifier<GraphQLClient> client = ValueNotifier(
    GraphQLClient(link: httpLink, cache: GraphQLCache()),
  );

  await PreferencesManager().init();


  runApp(MyApp(client: client));
}

class MyApp extends StatelessWidget {
  final ValueNotifier<GraphQLClient> client;

  const MyApp({super.key, required this.client});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (BuildContext context) => HomeController(),
      child: GraphQLProvider(
        client: client,
        child: MaterialApp(
          theme: ThemeData(
            appBarTheme: AppBarTheme(
              backgroundColor: Colors.blue,
              titleTextStyle: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          home: MainScreen(),
        ),
      ),
    );
  }
}
