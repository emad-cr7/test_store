import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:loading_animation_widget/loading_animation_widget.dart';
import 'package:page_transition/page_transition.dart';
import '../auth/login/login_screen.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});



  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    return AnimatedSplashScreen(
      duration: 2400,
      splashIconSize: 260,
      splashTransition: SplashTransition.fadeTransition,
      pageTransitionType: PageTransitionType.fade,
      backgroundColor: colors.primary,
      splash: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: colors.onPrimary.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(
                color: colors.onPrimary.withOpacity(0.3),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.15),
                  blurRadius: 30,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Icon(
              Icons.shopping_bag_outlined,
              size: 46,
              color: colors.onPrimary,
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'QL Shop',
            style: textTheme.titleLarge?.copyWith(
              color: colors.onPrimary,
              fontSize: 28,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Shop the best, effortlessly',
            style: textTheme.bodySmall?.copyWith(
              color: colors.onPrimary.withOpacity(0.85),
              fontSize: 13,
              letterSpacing: 0.3,
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: 30,
            height: 30,
            child: LoadingAnimationWidget.fourRotatingDots(
              color: Colors.blue,
              size: 30,
            ),
          ),
        ],
      ),
      nextScreen: const LoginScreen(),
    );
  }
}